# Travelling-Website
 A web application that is used as a simple travelling  website. The website allows the users to lookup several travelling destinations.

 >[!TIP]
>- Replace the folders "views" and "public" in your projects with the folders in this zip file.
>
>- "views" folder contains all the .ejs files written in HTML, "public" folder contains all the images needed for the project.
>
>- You won't be able to GET or POST the .ejs files until you configure them correctly in the app.js file.
>
>- You will have to get the videos links yourself and embed them from youtube or any other website. Don't download the videos so that the size of your project would remain small. Submissions have a size limit.
